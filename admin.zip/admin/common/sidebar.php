<div class=" sidebar" role="navigation">
            <div class="navbar-collapse">
				<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
					<ul class="nav" id="side-menu">
						<li>
							<a href="index.html"><i class="fa fa-home nav_icon"></i>Dashboard</a>
						</li>
						<li>
							<a href="#"><i class="fa fa-cogs nav_icon"></i>Manage technology  <span class="fa arrow"></span></a>
							<ul class="nav nav-second-level collapse">
								<li>
									<a href="add_cat.php">Add techonology</a>
								</li>
								<li>
									<a href="all_cat.php">All techonology
									</a>
								</li>
							</ul>
							<!-- /nav-second-level -->
						</li>
						<li>
							<a href="v_user.php"><i class="fa fa-home nav_icon"></i>View all user</a>
						</li>
						<li>
							<a href="v_company.php"><i class="fa fa-th-large nav_icon"></i>View all compnay</a>
						</li>
						<li>
							<a href="v_project.php"><i class="fa fa-home nav_icon"></i>View all project</a>
						</li>
						<li>
							<a href="v_que_ans.php"><i class="fa fa-home nav_icon"></i>View all quetions and answer</a>
						</li>
						<li>
							<a href="v_feedback.php"><i class="fa fa-home nav_icon"></i>View all feedback</a>
						</li>
						
						<li>
							<a href="tables.php"><i class="fa fa-table nav_icon"></i>Tables <span class="nav-badge">05</span></a>
						</li>
						<li>
							<a href="#"><i class="fa fa-check-square-o nav_icon"></i>Forms<span class="fa arrow"></span></a>
							<ul class="nav nav-second-level collapse">
								<li>
									<a href="forms.php">Basic Forms <span class="nav-badge-btm">07</span></a>
								</li>
								<li>
									<a href="validation.php">Validation</a>
								</li>
							</ul>
							<!-- //nav-second-level -->
						</li>
					</ul>
					<div class="clearfix"> </div>
					<!-- //sidebar-collapse -->
				</nav>
			</div>
		</div>