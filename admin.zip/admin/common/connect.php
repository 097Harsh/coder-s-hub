<?php

// Database Connection
$obj = new mysqli("localhost","root","","p2");

if($obj->connect_errno != 0)
{
	echo $obj->connect_error;
	exit;
}

?>